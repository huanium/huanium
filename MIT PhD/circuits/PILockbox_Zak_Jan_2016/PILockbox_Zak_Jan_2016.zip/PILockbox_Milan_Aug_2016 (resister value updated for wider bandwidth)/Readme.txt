Wiki page:
https://wikis.mit.edu/confluence/display/CUAWIKI/Rb+Lab+Milan+2016-07-21