#ifndef RENDER_HPP
#define RENDER_HPP


namespace render {
    void startOpenGL();
    void cleanup();

}

#endif