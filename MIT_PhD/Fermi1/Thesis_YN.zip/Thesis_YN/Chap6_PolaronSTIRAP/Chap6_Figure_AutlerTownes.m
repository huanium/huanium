%% load data
clear;
cd(fileparts(matlab.desktop.editor.getActiveFilename));

% 830nm triplet EIT 
AT_804nm = load('..\..\202206\220602\run4_AutlerTownesDownlegFreqScan_upleg1W_downleg57mW_100us\analysisContainer.mat');

% note the plot is generated from the date folder above

