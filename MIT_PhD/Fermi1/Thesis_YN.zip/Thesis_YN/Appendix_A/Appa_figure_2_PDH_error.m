%% load data
clear;
cd(fileparts(matlab.desktop.editor.getActiveFilename));

% PDH error signal from EIT decay measurement 

dir_PDHerror = '..\..\202207\220706\run4_EIT_time_evolution_TiSaHoldLock\PDH_Error_uplegHoldLock.csv';